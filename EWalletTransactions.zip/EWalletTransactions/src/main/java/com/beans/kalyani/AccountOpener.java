package com.beans.kalyani;
import java.sql.*;

public class AccountOpener 
{
	private int Accno;
	private String Accnm;
	private String Acctyp;
	private String Mob;
	private String EmailID;
	private String Accstatus;
	private double Balance;
	
	public AccountOpener()
	{
		Accstatus="NA";
	}

	public String getAccstatus() {
		return Accstatus;
	}

	public void setAccno(int accno) {
		this.Accno = accno;
	}

	public void setAccnm(String accnm) {
		this.Accnm = accnm;
	}

	public void setAcctyp(String acctyp) {
		this.Acctyp = acctyp;
	}

	public void setMob(String mob) {
		this.Mob = mob;
	}

	public void setEmailID(String emailID) {
		EmailID = emailID;
	}

	public void setBalance(double balance) {
		this.Balance = balance;
		insertAccount();
	}
	private void insertAccount()
	{
		Connection con;
		PreparedStatement pst;
		
		try
		{
			//Class.forName("com.mysql.cj.jdbc.Driver");
			//con=DriverManager.getConnection("jdbc:mysql://uy2uq2mvfn9z6x1i:BN7IqBWBenELiU0VhZI8@bzrmtozvhz0atspovaxl-mysql.services.clever-cloud.com:3306/bzrmtozvhz0atspovaxl?user=uy2uq2mvfn9z6x1i&password=uy2uq2mvfn9z6x1i");
			CloudDBConnect obj=new CloudDBConnect();
			con=obj.getDbconnection();
			pst=con.prepareStatement("insert into account values(?,?,?,?,?,?);");
			pst.setInt(1,Accno);
			pst.setString(2,Accnm);
			pst.setString(3, Acctyp);
			pst.setString(4, Mob);
			pst.setString(5, EmailID);
			
			pst.setDouble(6, Balance);
			pst.executeUpdate();
			Accstatus="success";
		
			con.close();
			
		}
	catch(Exception e)
		{
			Accstatus="failed";
			System.out.println(e);		}
	}
	
}
