package com.beans.kalyani;

import java.sql.*;

public class CloudDBConnect {
	
	private Connection dbconnection;
	
	public CloudDBConnect()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbconnection=DriverManager.getConnection("jdbc:mysql://uy2uq2mvfn9z6x1i:BN7IqBWBenELiU0VhZI8@bzrmtozvhz0atspovaxl-mysql.services.clever-cloud.com:3306/bzrmtozvhz0atspovaxl?user=uy2uq2mvfn9z6x1i&password=uy2uq2mvfn9z6x1i");
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public Connection getDbconnection() {
		return dbconnection;
	}


}
