package com.kalyani.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.kalyani.CloudDBConnect;

import java.sql.*;

/**
 * Servlet implementation class AddAccounts
 */
@WebServlet("/AddAccounts")
public class AddAccounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAccounts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String an,nm,at,mb,em,bl;
		an=request.getParameter("ano");
		nm=request.getParameter("anm");
		at=request.getParameter("atyp");
		mb=request.getParameter("mob");
		em=request.getParameter("eml");
		bl=request.getParameter("bal");
		
		
		//out.println(id+","+ps+","+nm+","+ct+","+mo+","+em);
		Connection con;
		PreparedStatement pst;
		
		try
		{
			CloudDBConnect obj=new CloudDBConnect();
			con=obj.getDbconnection();
			pst=con.prepareStatement("insert into account values(?,?,?,?,?,default,?);");
			pst.setString(1, an);
			pst.setString(2, nm);
			pst.setString(3, at);
			pst.setString(4, mb);
			pst.setString(5, em);
			pst.setString(6, bl);
			pst.executeUpdate();
			
			//out.println("<h3>Account created successfully</h3>");
			response.sendRedirect("AccSuccess.html");
			con.close();
			
		}
		catch(Exception e)
		{
			out.println(e);
		}
		out.println("<br><a href='index.jsp'>Home</a>");
	}

	}


