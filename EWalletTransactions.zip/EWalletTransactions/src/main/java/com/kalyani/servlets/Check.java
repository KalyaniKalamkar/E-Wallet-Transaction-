package com.kalyani.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.kalyani.*;
import java.sql.*;
/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id,ps;
		id=request.getParameter("uid");
		ps=request.getParameter("psw");
		//out.println(id+","+ps);
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			CloudDBConnect obj=new CloudDBConnect();
			con=obj.getDbconnection();
			pst=con.prepareStatement("select * from userinfo where UserID=? and Password=? and userstatus='active';");
			pst.setString(1, id);
			pst.setString(2, ps);
			rs=pst.executeQuery();
			if(rs.next())
			{
				HttpSession session=request.getSession(true);
				session.setAttribute("UserID", id);
				
				if(rs.getString("usertype").equals("customer"))
					response.sendRedirect("Customer.jsp");
				else
					response.sendRedirect("Admin.jsp");
			}
			else
				//out.println("authentication failed");
				response.sendRedirect("Failure.jsp");
			
			con.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
