package com.kalyani.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.kalyani.CloudDBConnect;
import com.beans.kalyani.AddTransactionRecord;

import java.sql.*;
import com.beans.kalyani.*;


/**
 * Servlet implementation class MoneyTransfer
 */
@WebServlet("/MoneyTransfer")
public class MoneyTransfer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MoneyTransfer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String trdt;
		HttpSession session=request.getSession(true);
		trdt=request.getParameter("transdt");
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		AddTransactionRecord T=new AddTransactionRecord();
		 
		
		String userid,fromacc,toacc,amount,pass;
		userid = request.getParameter("uid");
		T.setUid(userid);
		pass=request.getParameter("pws");
		fromacc=request.getParameter("facc");
		T.setFacc(fromacc);
		toacc=request.getParameter("tacc");
		T.setTacc(toacc);
		amount=request.getParameter("tamt");
		T.setTamt(amount);
		
		
		//out.println(userid+" "+pass+" "+fromacc+" "+toacc);
		Connection con;
        PreparedStatement pst,pst1,pst2,pst3;
        ResultSet rs;
		CloudDBConnect obj=new CloudDBConnect();
			
	      
	        try{
	        	con=obj.getDbconnection();
	          
	        	pst2=con.prepareStatement("select * from userinfo where UserID=? and Password=? and userstatus='active';");
				pst2.setString(1, userid);
	        	pst2.setString(2, pass);
				rs=pst2.executeQuery();
				
				
				
	        	if(rs.next()) {
	            
	           
	        	
	            pst1 = con.prepareStatement("UPDATE account SET Balance=Balance-? where Accno=? and Accno=?;");
	            pst1.setString(1, amount);
	            pst1.setString(2, fromacc);
	            pst1.setString(3, userid);
	            
	            pst = con.prepareStatement("UPDATE account SET Balance=Balance+? where Accno=?;");
	            pst.setString(1, amount);
	            pst.setString(2, toacc);
	            
	           
	            int cnt1 = pst1.executeUpdate();
	            int cnt = pst.executeUpdate();
	            if(cnt == 1 && cnt1 == 1){
	               response.sendRedirect("transfersuccess.html");
	            	
	            }
	           
	        	
	            else{
	            	pst3 = con.prepareStatement("UPDATE account SET Balance=Balance-? where Accno=?;");
		            pst3.setString(1, amount);
		            pst3.setString(2, toacc);
		            pst3.execute();
	                response.sendRedirect("transferfailed.html");
		            
	            }
	        	}
	            con.close();
	          
	        }
	        catch(Exception e){
	            out.println(e);
	            out.println("NO data found");
	           
	        }
	      
	        
	}
			
}
	



