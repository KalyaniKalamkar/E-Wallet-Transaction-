package com.kalyani.servlets;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.kalyani.*;
import com.kalyani.servlets.*;

import java.sql.*;

/**
 * Servlet implementation class MoneyAdded
 */
@WebServlet("/MoneyAdded")
public class MoneyAdded extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MoneyAdded() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String an,am,ps;
		
		an=request.getParameter("ano");
		ps=request.getParameter("pws");
		am=request.getParameter("amt");
		//out.println(id+","+am);
		
		Connection con;
		PreparedStatement pst,pst1;
		ResultSet rs;
		
		try
		{
			CloudDBConnect obj=new CloudDBConnect();
			con=obj.getDbconnection();
			
			pst1=con.prepareStatement("select * from userinfo where UserID=? and Password=?");
            pst1.setString(1,an);
            pst1.setString(2, ps);
            rs=pst1.executeQuery();
            if(rs.next()) {
	            pst = con.prepareStatement("UPDATE account SET Balance=Balance+? where Accno=?;");
	            pst.setString(1, am);
	            pst.setString(2, an);
	            
	            int cnt = pst.executeUpdate();
	            
	            if(cnt == 1){
	              response.sendRedirect("moneyaddedtowallet.html");
	            	//out.println("Money Added Successfully!!");
	            }
	            else{
	            	//response.sendRedirect("fail.html");
	            	out.println("Failed");
	            }
	            }
	            con.close();
	        }
	        catch(Exception e){
	            out.println(e);
	            
	        }
	        //response.sendRedirect("moneyaddedtowallet.html");
		
		response.sendRedirect("fail.html");
		out.println("<br><a href='Customer.jsp'>Home</a>");
	}
		
		
	
	}

	


