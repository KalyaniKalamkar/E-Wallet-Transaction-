package com.kalyani.servlets;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.beans.kalyani.*;
import java.sql.*;
/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id,ps,nm,ct,mo,em;
		id=request.getParameter("uid");
		ps=request.getParameter("psw");
		nm=request.getParameter("unm");
		mo=request.getParameter("mob");
		em=request.getParameter("eml");
		ct=request.getParameter("cty");
		
		
		//out.println(id+","+ps+","+nm+","+ct+","+mo+","+em);
		Connection con;
		PreparedStatement pst;
		
		try
		{
			CloudDBConnect obj=new CloudDBConnect();
			con=obj.getDbconnection();
			pst=con.prepareStatement("insert into userinfo values(?,?,?,default,default,?,?,?);");
			pst.setString(1, id);
			pst.setString(2, ps);
			pst.setString(3, nm);
			pst.setString(4, mo);
			pst.setString(5, em);
			pst.setString(6, ct);
			pst.executeUpdate();
			
			//out.println("<h3>User Registered successfully</h3>");
			response.sendRedirect("RegSuccess.jsp");
			con.close();
			
		}
		catch(Exception e)
		{
			out.println(e);
			response.sendRedirect("RegFail.jsp");
		}
		out.println("<br><a href='index.jsp'>Home</a>");
	}

}
